#!/bin/bash
#Script generico para copiar resultados de una tarea a un subdirectorio
#Se suministra como parametro el directorio padre que va a contener
#el directorio del mismo nombre de la tarea
#Este fichero se debe copiar en el subdirectorio postprocess del modulo
#Si se desea que en vez de copiar, se muevan los datos, hay que modificar
#la ultima linea de /bin/cp a /bin/mv

DIR=`pwd`
TARGET=`basename $DIR`

if [ ! -d ${1}/${TARGET} ]
  then
    mkdir ${1}/${TARGET}
fi

/bin/cp -r -f . ${1}/${TARGET}

